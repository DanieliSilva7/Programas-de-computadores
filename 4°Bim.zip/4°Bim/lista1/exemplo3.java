public class exemplo3 {
    
/*/Crie uma função que peça ao usuário um número e retorne o número informado. Ela deve validar se ele é maior que 0 e menor que 1.000. Caso não seja, 
informe número inválido. No corpo do programa, crie um vetor de 10 posições de inteiros e para preencher o vetor, 
chame a função criada anteriormente. No final, exiba os números informados pelo usuário. */

}
