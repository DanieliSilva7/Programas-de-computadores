
import java.util.Scanner;

public class exemplo2 {

    static Scanner s = new Scanner(System.in);

    /*
    Crie uma função chamada solicita_texto que peça ao usuário uma String e retorne o valor informado desde que tenha mais do que 5 caracteres. 
    Caso o texto tenha menos caracteres, informe “Palavra muito pequena”. Depois, no corpo do programa crie um vetor de 5 posições de Strings
    chamado frutas e use a função para preenchê-lo.
     */
    public static void main(String[] args) {
        ex_2();

    }

    public static void ex_2() {

        String[] frutas = new String[5];
        frutas[0] = solicita_texto();
        frutas[1] = solicita_texto();
        frutas[2] = solicita_texto();
        frutas[3] = solicita_texto();
        frutas[4] = solicita_texto();
       
        System.out.println("Primeira fruta:" + frutas[0]);
        System.out.println("Segunda fruta" + frutas[1]);
        System.out.println("Terceiro fruta" + frutas[2]);
        System.out.println("Quarta fruta" + frutas[3]);
        System.out.println("Quinta fruta" + frutas[4]);
    }

    public static String solicita_texto() {
        String palavra = "";

        while (palavra.length() < 5) {
            System.out.println("Informe uma palavra: ");
            palavra = s.next();
            if (palavra.length() < 5) {
                System.out.println("Palavra muito pequena");
            }

        }

        return palavra;

    }

}
