public class exemplo2 {
    /*
    Crie uma função chamada solicita_texto que peça ao usuário uma String e retorne o valor informado desde que tenha mais do que 5 caracteres. 
    Caso o texto tenha menos caracteres, informe “Palavra muito pequena”. Depois, no corpo do programa crie um vetor de 5 posições de Strings
    chamado frutas e use a função para preenchê-lo.
     */

     String solicita_texto;

     public static void main(String[] args) {
         






     }

}
