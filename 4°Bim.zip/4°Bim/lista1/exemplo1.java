import java.util.Scanner;

public class exemplo1{

/*
1. Crie uma função chamada calculo, com retorno double/real e que receba dois parâmetros double/real. Quando num1 for maior que num2, ela deve retornar a multiplicação dos dois.
 Quando o num1 for menor que num2, deve-se retornar a divisão entre os dois. Quando eles forem iguais, deve-se retornar a soma deles.
 */

public static void main(String[] args) {

    double valor1, valor2;
    Scanner s = new Scanner(System.in);
    System.out.println("Informe valor 1:");
    valor1 = s.nextDouble();
    System.out.println("Informe valor 2:");
    valor2 = s.nextDouble();

    System.out.println("Resultado do calculo: " + calculo(valor1, valor2));

}
    public static double calculo(double num1, double num2){

        if(num1 > num2){
            return num1 * num2;
        }else if (num2 > num1){
            return num1 / num2 ;
        }else{
            return num1 + num2;
        }

    
        }

    }

