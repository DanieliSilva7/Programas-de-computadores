import java.util.Scanner;

    public class lista_vetores {
    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {
        
    }

    public static void ex_01() {

        
        double notas [] = new double[4];

        //Preecher o vetor manualmente:

        notas[0] = pedir_numero_double();
        notas[1] = pedir_numero_double();
        notas[2] = pedir_numero_double();
        notas[3] = pedir_numero_double();
        
        //Exibir valores do vetor manualmente:
        System.out.println("Notas informadas:");
        System.out.println("Nota 1: " + notas[0]);
        System.out.println("Nota 2: " + notas[1]);
        System.out.println("Nota 3: " + notas[2]);
        System.out.println("Nota 4: " + notas[3]);
        
        //Preencher o vetor com for:
        
        for (int i =0; i< notas.length ;i++ ){
            notas[i] = pedir_numero_double();
        }


        //Exibir valores do vetor com for:
        

    }

    public static double pedir_numero_double() {

        System.out.print("Informe um numero (real): ");
        return s.nextDouble();
    }

        public static void exemplo_matriz(){
            double alturas_aluno [] [] = new double[3][7];

            //imprimindo matriz//
            for(int i=0; i<alturas_aluno.length; i++){
                for(int j=0; j<alturas_aluno [i].length; j++){
                    
                }
            }
        



    }
}
