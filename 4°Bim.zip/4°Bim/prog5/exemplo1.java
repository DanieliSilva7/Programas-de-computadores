import java.util.Scanner;

public class exemplo1 {
    


/*1. Declare um vetor do tipo real, com 4 posições. 
Peça as notas dos 4 bimestres de um aluno e no final calcule a média.  */


}
