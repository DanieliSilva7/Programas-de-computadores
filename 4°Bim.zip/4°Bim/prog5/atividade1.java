import java.util.Scanner;

public class atividade1 {
    
    /*1.Peça ao usuário quantos preços ele deseja informar. Crie um vetor, peça ao usuário os preços e armazene em cada posição.
     Depois exiba: O Menor, o Maior e a média dos preços.  */

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

    }
    public static void ex_01 () {

        System.out.print("Quantos preços deseja informar? ");
        int n = s.nextInt();

        double precos[] = new double[n];

        
        for (int i = 0; i < precos.length; i++) {
            System.out.println("Informe o preço " + (i + 1) + ": ");
            precos[i] = pedir_numero_double();
        }

        
        double menor = precos[0];
        double maior = precos[0];
        double soma = 0;

        for (int i = 0; i < precos.length; i++) {
            if (precos[i] < menor) {
                menor = precos[i];
            }
            if (precos[i] > maior) {
                maior = precos[i];
            }
            soma += precos[i];
        }

        double media = soma / precos.length;

        // Exibir resultados:
        System.out.println("\n--- Resultados ---");
        System.out.println("Menor preço: R$ " + menor);
        System.out.println("Maior preço: R$ " + maior);
        System.out.println("Média dos preços: R$ " + media);
    }

    public static double pedir_numero_double() {
        System.out.print("Informe um número (real): ");
        return s.nextDouble();
    }
}

















