import java.util.Scanner;

public class Exercicio1 {
    
    /*1.Peça ao usuário quantos preços ele deseja informar. Crie um vetor, peça ao usuário os preços e armazene em cada posição.
     Depois exiba: O Menor, o Maior e a média dos preços.  */

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

        int exercicio;

        do{
            System.out.print("Informe qual o exercicio deseja executar (0 para sair): ");
            exercicio = s.nextInt();

            switch (exercicio) {
                case 1:
                    ex_01();
                    break;

                    case 2 :
                    ex_02();
                    break;

                default:
                if (exercicio != 0) {
                    System.out.print("Exercicio Invalido!");
                }
            }

        } while (exercicio != 0);

    }
    public static void ex_01 () {

        System.out.print("Quantos preços deseja informar? ");
        int n = s.nextInt();

        double precos[] = new double[n];

        
        for (int i = 0; i < precos.length; i++) {
            System.out.println("Informe o preço " + (i + 1) + ": ");
            precos[i] = pedir_numero_double();
        }

        
        double menor = precos[0];
        double maior = precos[0];
        double soma = 0;

        for (int i = 0; i < precos.length; i++) {
            if (precos[i] < menor) {
                menor = precos[i];
            }
            if (precos[i] > maior) {
                maior = precos[i];
            }
            soma += precos[i];
        }

        double media = soma / precos.length;

        System.out.println("\n Resultados ");
        System.out.println("Menor preço: R$ " + menor);
        System.out.println("Maior preço: R$ " + maior);
        System.out.println("Média dos preços: R$ " + media);
    }

    public static double pedir_numero_double() {
        System.out.print("Informe um número (real): ");
        return s.nextDouble();
  
    }

         /*Declare uma Matriz 5 linhas por 2 colunas de inteiro. A primeira coluna deve ser armazenado o RA. Na segunda, a quantidade de faltas. 
    Preencha a matriz e depois exiba aluno por aluno, o RA, a quantidade de faltas e se ele está aprovado ou reprovado por faltas. 
    Considere a seguinte regra: O aluno que tiver mais de 20 faltas, estará "reprovado por faltas". O aluno que tiver 20 ou menos, esta aprovado. */

    public static void ex_02 () {
        int[][] matriz = new int[5][2];

        System.out.println("\nInforme o RA e as faltas dos 5 alunos:");
        for (int i = 0; i < 5; i++) {
            System.out.print("RA do aluno " + (i + 1) + ": ");
            matriz[i][0] = s.nextInt();
            System.out.print("Quantidade de faltas: ");
            matriz[i][1] = s.nextInt();
            System.out.println();
        }

        System.out.println("\n Situação dos Alunos ");
        for (int i = 0; i < 5; i++) {
            int ra = matriz[i][0];
            int faltas = matriz[i][1];
            String situacao = (faltas > 20) ? "Reprovado por faltas" : "Aprovado";
            System.out.println("RA: " + ra + " | Faltas: " + faltas + " | Situação: " + situacao);
        }
    }
}


