import java.util.Scanner;
import java.util.Random;

public class exemplo4{

Scanner s = new Scanner(System.in);

public static void ex_04(){


/*4. Crie dois vetores de 8 posições para armazenar números inteiros.
 Agora crie um terceiro do mesmo tamanho e armaze em cada posição a multiplicação dos valores armazenados nas mesma posição nos dois primeiros. */
    

    int tamanho = 10;
    int[] numA = new int[tamanho];
    int[] numB = new int[tamanho];
    int[] mult = new int [tamanho];

    numA = preenche_vetor_int(tamanho);
    numB = preenche_vetor_int(tamanho);

    imprime_vetor(numA);
    imprime_vetor(numB);


    for(int i=0; i<tamanho; i++){

        mult[i] = numA[i] * numB[i];

    }
}

public static int [] preenche_vetor_int (int tamanho){

    int[] vetor = new int[tamanho];
    Random r = new Random();//Variável para gerar números aleatórios.

    for(int i=0; i<tamanho; i++){

        vetor[i] = r.nextInt(0,100); //Preenchendo o veto com números

    }
    return vetor;

}
    public static void imprime_vetor(int[] vetor) {
        
        System.out.println("Valor do Vetor:");
        for(int i=0; i <vetor.length; i++){
            System.out.print(vetor[i] + "-");
        }

    }


}