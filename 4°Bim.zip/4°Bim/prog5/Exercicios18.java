import java.util.Scanner;

public class Exercicios18 {

/*Exercício 1 - Cris quer fazer uma base de dados para armazenar as cores de cada pedido de crochê que ela faz. Ela iniciou seus estudos em programação, 
mas ainda não conseguiu implementar uma solução satisfatória. Ela precisa armazenar o número do pedido, o nome da cliente, a cor principal, cor secundária e a cor complementar.
Todos os valores são textos. Crie um programa que resolva o problema dela e ainda utilizando matriz e que, ao informar um código de pedido, retorne o número do pedido, nome do cliente e
quais as cores do mesmo, conforme apresentado acima. Use funções para organizar o código. */
public static void preencherPedidos(String[][] pedidos) {
Scanner sc = new Scanner(System.in);

for (int i = 0; i < pedidos.length; i++) {
System.out.println("\n--- Cadastro do pedido " + (i + 1) + " ---");

System.out.print("Número do pedido: ");
pedidos[i][0] = sc.nextLine();

System.out.print("Nome da cliente: ");
pedidos[i][1] = sc.nextLine();

System.out.print("Cor principal: ");
pedidos[i][2] = sc.nextLine();

System.out.print("Cor secundária: ");
pedidos[i][3] = sc.nextLine();

System.out.print("Cor complementar: ");
pedidos[i][4] = sc.nextLine();
}
}


public static void buscarPedido(String[][] pedidos, String numeroPedido) {
boolean encontrado = false;

for (int i = 0; i < pedidos.length; i++) {
if (pedidos[i][0].equalsIgnoreCase(numeroPedido)) {
System.out.println("\n--- Pedido encontrado ---");
System.out.println("Número do pedido: " + pedidos[i][0]);
System.out.println("Cliente: " + pedidos[i][1]);
System.out.println("Cor principal: " + pedidos[i][2]);
System.out.println("Cor secundária: " + pedidos[i][3]);
System.out.println("Cor complementar: " + pedidos[i][4]);
encontrado = true;
break;
}
}

if (!encontrado) {
System.out.println("\nPedido não encontrado.");
}
}

/*Exercício 2 - João deseja converter os meses informados em números inteiros para o seu nome ou abreviação. Crie uma função que ajude joão a resolver esse problema. 
A função deve receber por parâmetro o mês e qual tipo de retorno deseja, e retornar um texto. */

public static String converterMes(int mes, String tipo) {

String[] meses = {
"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
"Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
};

String[] abreviados = {
"Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
"Jul", "Ago", "Set", "Out", "Nov", "Dez"
};

if (mes < 1 || mes > 12) {
return "Mês inválido.";
}

if (tipo.equalsIgnoreCase("nome")) {
return meses[mes - 1];
} else if (tipo.equalsIgnoreCase("abreviacao")) {
return abreviados[mes - 1];
} else {
return "Tipo inválido. Use 'nome' ou 'abreviacao'.";
}
}



public static void main(String[] args) {

Scanner sc = new Scanner(System.in);


System.out.println("EXERCÍCIO UM: - Cadastro de pedidos de crochê\n");

String[][] pedidos = new String[3][5]; 

preencherPedidos(pedidos);

System.out.print("\nDigite o número do pedido que deseja buscar: ");
String numeroBusca = sc.nextLine();

buscarPedido(pedidos, numeroBusca);


System.out.println("\n\nEXERCÍCIO DOIS - Conversão de meses\n");

System.out.print("Digite o número do mês (1 a 12): ");
int mes = sc.nextInt();
sc.nextLine(); 

System.out.print("Digite o tipo: ");
String tipo = sc.nextLine();

String resultado = converterMes(mes, tipo);
System.out.println("Resultado: " + resultado);
}
}
