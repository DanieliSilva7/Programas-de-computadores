
import java.util.Scanner;

public class fatorial {

    public static void main(String[] args) {

        int numero;

        Scanner s = new Scanner(System.in);
        System.out.print("Informe um número para calcular o fatorial: ");
        numero = s.nextInt();

        System.out.println("Fatorial é: " + fatorial(numero));

        System.out.println("Fatorial é:" + fatorial(numero));

    }

    public static int fatorial(int n) {

        System.out.println(n);
        if (n == 1 || n == 0) {
            return 1; 
        }else {
            return n * fatorial(n - 1);
        }
    }

}
