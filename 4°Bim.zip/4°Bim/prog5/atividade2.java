import java.util.Scanner;

public class atividade2 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Escolha o exercício para executar:");
        System.out.println("1 - Atividade");
        System.out.println("2 - Atividade");
        System.out.print("Opção: ");
        int opcao = input.nextInt();

        switch (opcao) {
            case 1:
                exercicioPrecos(input);
                break;
            case 2:
                exercicioFaltas(input);
                break;
            default:
                System.out.println("Opção inválida!");
        }

        input.close();
    }

   /*1.Peça ao usuário quantos preços ele deseja informar. Crie um vetor, peça ao usuário os preços e armazene em cada posição.
     Depois exiba: O Menor, o Maior e a média dos preços.  */

    public static void exercicioPrecos(Scanner input) {
        System.out.print("Quantos preços deseja informar? ");
        int n = input.nextInt();
        double[] precos = new double[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Informe o preço " + (i + 1) + ": ");
            precos[i] = input.nextDouble();
        }

        double menor = precos[0];
        double maior = precos[0];
        double soma = 0;

        for (double preco : precos) {
            if (preco < menor) menor = preco;
            if (preco > maior) maior = preco;
            soma += preco;
        }

        double media = soma / n;

        System.out.println("\n Resultados ");
        System.out.println("Menor preço: R$ " + menor);
        System.out.println("Maior preço: R$ " + maior);
        System.out.println("Média dos preços: R$ " + media);
    }

  /*Declare uma Matriz 5 linhas por 2 colunas de inteiro. A primeira coluna deve ser armazenado o RA. Na segunda, a quantidade de faltas. 
    Preencha a matriz e depois exiba aluno por aluno, o RA, a quantidade de faltas e se ele está aprovado ou reprovado por faltas. 
    Considere a seguinte regra: O aluno que tiver mais de 20 faltas, estará "reprovado por faltas". O aluno que tiver 20 ou menos, esta aprovado. */

    public static void exercicioFaltas(Scanner input) {
        int[][] matriz = new int[5][2];

        System.out.println("\nInforme o RA e as faltas dos 5 alunos:");
        for (int i = 0; i < 5; i++) {
            System.out.print("RA do aluno " + (i + 1) + ": ");
            matriz[i][0] = input.nextInt();
            System.out.print("Quantidade de faltas: ");
            matriz[i][1] = input.nextInt();
            System.out.println();
        }

        System.out.println("\n Situação dos Alunos ");
        for (int i = 0; i < 5; i++) {
            int ra = matriz[i][0];
            int faltas = matriz[i][1];
            String situacao = (faltas > 20) ? "Reprovado por faltas" : "Aprovado";
            System.out.println("RA: " + ra + " | Faltas: " + faltas + " | Situação: " + situacao);
        }
    }
}


    

