import java.util.Scanner;

public class exemplo_tabuada{
public static void main(String[] args) {
    /* Classe de repetição */
/*Faça um algoritmo que peça um número ao usuário e exiba a tabuada desse número do 1 ao 10. */

/* Divissão de um problema em partes:
Parte 1: Define as variáveis e seus tipos
Parte 2: Obter os valores para as variáveis (pedir ao usuário ou informar)
Parte 3: Fazer os calculos necessarios
Parte 4: mostrar os resultados */


    int num;

    Scanner s = new Scanner(System.in);

    System.out.print("Informe um numero para calcular a tabuada: ");
    num = s.nextInt();

    /* Exemplo usando println ou print*/
    System.out.println("\nTabuada do " + num + ":");
    for(int i = 1; i <= 10; i++){
        System.out.println(num + " X " + i + " = " + (num*i));
    }
    /* Exemplo usando printf */
    System.out.println("\n Tabuada do " + num + ":");
    for(int i = 1; i <= 10; i++){
        System.out.printf("%d x %d = %d\n", num, i, (num*i));
        }

    }

}