
import java.util.Scanner;

public class teste {
public static void main(String[] var0) {

int cont;
cont = 5;

System.out.println("Exemplo com Enquanto (While):");
 while (cont <5){
    System.out.println("contador: "+ cont);
    //cont++;
 }

cont = cont + 1;

System.out.println("Exemplo com Repita (do): ");
cont = 5;
do {
    System.out.println("contador: "+ cont);
    cont++;
}while (cont < 5);

}



}
