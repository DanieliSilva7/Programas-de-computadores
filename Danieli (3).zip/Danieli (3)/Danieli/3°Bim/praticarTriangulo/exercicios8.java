import java.util.Scanner;

public  class exercicios8 {


public static void main(String[] args) {

/*Dado os três valores, A, B e C, verificar se eles podem ser os comprimentos dos lados de um triângulo, se forem, verificar se compõem um triângulo equilátero, isósceles ou escaleno 
Dados de Entrada: Três lados de um suposto triângulo A, B e C.
Dados de saída: mensagens: não compõem um triângulo, triângulo equilátero, triângulo isósceles, triângulo escaleno.
É um triângulo?: Figura geométrica fechada de três lados, em que cada um é menor que a soma dos outros dois. 
Triângulo equilátero: possui três lados iguais.
Triângulo isósceles: possui dois lados iguais.
Triângulo escaleno: possui todos os lados diferentes. */


int lado_A;
int lado_B;
int lado_C;

Scanner s = new Scanner (System.in);

System.out.print("Triangulo A: ");
lado_A = s.nextInt();

System.out.print("Triangulo B: ");
lado_B = s.nextInt();

System.out.print("Triangulo C: ");
lado_C = s.nextInt();

    if ((lado_A < lado_B + lado_C) && 
        (lado_B < lado_A + lado_C) && 
        (lado_C < lado_A + lado_B)) {
    }else
    System.err.println("Os valores não forma um triangulo valido");
  
            if ((lado_A == lado_B) && 
                (lado_B == lado_C )&&
                (lado_C == lado_A)) {
            System.out.println("Triangulo é equilatero");
            }else if ((lado_A == lado_B) || (lado_B == lado_C) || (lado_C == lado_A)){
                System.out.println("Triangulo é isosceles");
            }else{
                System.out.println("Triangulo é escaleno");
            }
        }
    }





