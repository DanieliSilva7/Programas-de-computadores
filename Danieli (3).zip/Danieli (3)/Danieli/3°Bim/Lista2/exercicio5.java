public class exercicio5 {
    

    /*Faça um algoritmo que leia o ano de nascimento de uma pessoa, calcule e exiba se: ela já tem idade para votar (16 anos ou mais); 
    se já tem idade para tirar habilitação (18 anos ou mais) ou se é menor de 16 anos “não pode nem votar nem tirar carteira”.
 */
}
