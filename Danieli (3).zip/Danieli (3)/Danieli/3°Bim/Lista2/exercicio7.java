public class exercicio7 {
/*Faça um programa que receba uma Mês em formato numérico (1 a 12). Caso o número informado não seja um mês, exiba a mensagem “Valor Inválido”. Depois,
 compare com o Mês atual e exiba se: “Mês já passou”, “Mês atual” ou “Mês Futuro”.  
 */ 

    
}
