
import java.util.Scanner;

public class exercicio2 {
   public static void main(String[] var0) {
/*Escreva um programa que leia a matrícula de um funcionário, seu número de horas trabalhadas,
 o valor que recebe por hora trabalhada, a qual mês se referem as informações (ex: “Maio/24”) e calcule o salário desse funcionário no mês.
  Mostre a matrícula, o número de horas, o mês, o salário total do funcionário e se o funcionário tece horas extras no mês. A quantidade normal de horas são 200h.
   O que exceder isso é considerado hora extra e deve ter um adicional no valor de 50%. */


int matricula;
double num_horas, valor_hora, valor_hora_extra, num_horas_extras, salario_normal, salario_extra, salario_total;
String mes;

Scanner s = new Scanner (System.in);

valor_hora_extra = 0;
salario_extra = 0;
num_horas_extras = 0;

System.out.println ("Programa para calculo do salário:");
System.out.println ("Matricula:");
matricula = s.nextInt();

System.out.println ("Valor da hora:");
valor_hora = s.nextDouble();

System.out.println ("Horas trabalhadas:");
num_horas = s.nextDouble();

System.out.println ("mes de referencia:");
mes = s.nextLine();


if (num_horas > 200){
   num_horas_extras = num_horas - 200;
   salario_extra  = valor_hora * 1.5;
   salario_extra = num_horas_extras * valor_hora_extra;

}

salario_normal = num_horas * valor_hora;
salario_total = salario_normal + salario_extra;

System.out.println("Salario calculado para o mes" + mes);
System.out.println("Matricula" + matricula);
System.out.println("Total de horas trabalhadas:" + num_horas);
System.out.println("Total de horas extras" + num_horas_extras);
System.out.println("Valor salario normal" + salario_extra);
System.out.println("valor salario extra" + salario_extra);
System.out.println("Salario total" + salario_total);

s.close();

}













}


