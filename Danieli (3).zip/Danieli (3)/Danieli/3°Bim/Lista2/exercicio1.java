public class exercicio1 {
  
    
/*Faça um algoritmo para calcular o volume de uma esfera de raio R, em que R é fornecido pelo usuário.
 o volume de uma esfera é dado por:  V = 4/3 π r³ */
    
}
