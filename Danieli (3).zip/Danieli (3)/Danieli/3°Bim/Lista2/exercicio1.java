import java.util.Scanner;

public class exercicio1 {
  
    
/*Faça um algoritmo para calcular o volume de uma esfera de raio R,
 em que R é fornecido pelo usuário.
 o volume de uma esfera é dado por:  V = 4/3 π r³ */
    

 public static void main(String[] args) {
     
double R,volume;

Scanner s = new Scanner(System.in);

System.err.println("Informa o valor do raio: ");
R = s.nextDouble();

//volume = (4 * Math.PI * Math.pow(R, 3) / 3);
volume = 4 / 3.0 * Math.PI * Math.pow(R, 3);

System.out.printf("Volume da esfera informada é: %.4f",volume);
 }
}   
