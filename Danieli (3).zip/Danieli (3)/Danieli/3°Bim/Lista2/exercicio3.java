public class exercicio3 {
    
/*Escreva um algoritmo que leia três valores diferentes e os escreva em ordem crescente. Utilize uma seleção encadeada.
 */

}
