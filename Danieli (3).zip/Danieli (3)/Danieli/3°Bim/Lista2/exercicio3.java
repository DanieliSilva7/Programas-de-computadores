import java.util.Scanner;

public class exercicio3 {
    
/*Escreva um algoritmo que leia três valores diferentes e os escreva em ordem crescente. Utilize uma seleção encadeada.
 */

public static void main(String[] args) {
   
    int num1, num2, num3;
    String msg = "";
    Scanner s = new Scanner (System.in);

    System.err.println("Informe o primeiro numero: ");
    num1 = s.nextInt();
    System.err.println("Informe o segundo numero: ");
    num2 = s.nextInt();
    System.err.println("Informe o terceiro numero: ");
    num3 = s.nextInt();

    if(num1 < num2 && num1 < num3){
        msg = num1 + "";

        
    }else if (true){

    }




 }
}
