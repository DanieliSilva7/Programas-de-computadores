public class exdia02{


public static void main(String[] args) {

int opcao;
String resultado;
opcao = 3;

switch (opcao) {
    case 1:
    resultado = "opção 1";
    break;

    case 2:
    resultado = "opção 2";
    break;

    case 3:
    resultado = "opção 3";
    break;

    case 4:
    resultado = "opção 4";
    break;

    case 5:
    resultado = "opção 5";
        break;
    default:
        resultado = "Opção invalida";
        break;
}
}
}


