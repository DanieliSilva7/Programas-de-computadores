class exemplo_01{

    public static void main(String[] args) {
        System.out.println("Ola Mundo! \n\n Esse é meu primeiro programa em Java.");

        int idade;
        idade = 15;

        System.out.println("idade:" + idade);
        
//Declarar uma variavel do tipo string chamada nome://
/*
exemplo para usar mais de uma linha/pular
*/

        String nome;
        nome = "Danieli";

System.out.println("nome:" + nome);

//declarar uma variável do tipo boolean chamada status_aluno//

boolean status_aluno;
status_aluno = true; // true = verdadeiro

System.out.println("status:" + status_aluno);

status_aluno = false; // false= falso


//declarar um variavel do tipo char chamada periodo:


char periodo;
periodo = '2';

System.out.println("periodo:" + periodo);

    }
}

