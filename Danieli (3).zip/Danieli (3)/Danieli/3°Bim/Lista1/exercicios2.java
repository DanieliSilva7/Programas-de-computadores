import java.util.Scanner;
class exercicios2{

/*/ Exercicio 02 */
/*Faça um programa que peça ao usuário Nome, idade, Gênero, Cor 
favorita e se pratica esporte e depois exiba as informações digitadas.
 */

public static void main(String[] args) {


String nome;
int idade;
String genero;
String cor;
String esporte;

Scanner s = new Scanner(System.in);

System.out.println("Nome:");
nome = s.next();

System.out.println("Idade");
idade = s.nextInt();

System.out.println("Genero");
genero = s.next();

System.out.println("Cor");
cor = s.next();

System.out.println("Esporte");
esporte = s.next();


System.out.println("Informe o Nome:" + nome);
System.out.println("Informe a Idade:" + idade);
System.out.println("Informe a Genero:" + genero);
System.out.println("Informe a Cor:" + cor);
System.out.println("Informe a Esporte:" + esporte);


}





}
