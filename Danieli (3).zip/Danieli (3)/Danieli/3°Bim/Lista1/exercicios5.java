
import java.util.Scanner;


/*Faça um programa que peça um número ao usuário. 
Exiba se esse número é Par ou Ímpar (use o operador de resto da divisão - mod %).  */

public class exercicios5 {
   public static void main(String[] args) {
   Scanner s = new Scanner (System.in);
   String resultado="Numero PAR";
   int num;
   System.out.println("Informe o primeiro numero:");
    num = s.nextInt();

    if (num % 2 != 0) {
        resultado = ("Numero IMPAR!");
    
    }
    System.out.println("Resultado" + resultado);


   }
    
}
