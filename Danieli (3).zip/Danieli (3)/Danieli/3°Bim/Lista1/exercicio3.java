
import java.util.Scanner;

/*/ Exercicio 03 */
/*Faça um programa que peça ao usuário dois números (num1 e num2) e depois exiba 
o resultado das operações matemáticas soma, divisão, subtração e multiplicação.
 */

public class exercicio3{
    public static void main (String[] args) {

    int num1;
    int num2;
    

   
    Scanner s = new Scanner(System.in);
/*/ pedir para o usuário /*/

System.out.println("Informe primeiro número:"); 
num1 = s.nextInt();
System.out.println("Informe o segundo número:");
num2 = s.nextInt();

System.out.println("Resultado das operações aritméticas:");
System.out.println( "Soma num1 + num2: " + (num1+num2));
System.out.println( "Subtração num1 - num2: " + (num1-num2));
System.out.println("Divisão num1/num2 " + (num1/num2));
System.out.println("Multiplicação num1 + num2: " +(num1*num2));
s.close();
}
}  