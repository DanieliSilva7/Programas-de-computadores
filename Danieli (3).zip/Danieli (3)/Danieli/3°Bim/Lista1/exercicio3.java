
import java.util.Scanner;

/*/ Exercicio 03 */
/*Faça um programa que peça ao usuário dois números (num1 e num2) e depois exiba 
o resultado das operações matemáticas soma, divisão, subtração e multiplicação.
 */

public class exercicio3{


public static void main (String[] args) {
    int num1;
    int num2;

    int soma;
    double divisao;
    int subtracao;
    int multiplicacao;

    Scanner s = new Scanner(System.in);

    



    
}
}  