public class exercicios6 {
   /*  Faça um programa que peça ao usuário um número inteiro qualquer
    e exiba esse número elevado a 2, 4, 6, 8 e 10 (use a biblioteca Math). */

public static void main(String[] arg) {
Scanner s = new Scanner(System.in);

int num;

System.out.print("Insira um numero: ");
num = s.nextFloat();

System.out.println("Resultado 2: :" +Math.pow(num, b:2));
System.out.println("Resultado 4: :" +Math.pow(num, b:4));
System.out.println("Resultado 6: :" +Math.pow(num, b:6));
System.out.println("Resultado 8: :" +Math.pow(num, b:8));
System.out.println("Resultado 10: :" +Math.pow(num, b:10));



    }   
}
