public class exercicios6 {
   /*  Faça um programa que peça ao usuário um número inteiro qualquer
    e exiba esse número elevado a 2, 4, 6, 8 e 10 (use a biblioteca Math). */


    



}
