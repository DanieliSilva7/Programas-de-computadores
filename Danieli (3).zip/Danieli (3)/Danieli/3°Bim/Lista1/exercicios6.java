import java.util.Scanner;


   /*  Faça um programa que peça ao usuário um número inteiro qualquer
    e exiba esse número elevado a 2, 4, 6, 8 e 10 (use a biblioteca Math). */
    public class exercicios6 {


    public static void main(String[] arg) {

    Scanner s = new Scanner (System.in);

    int num;
    double eleva2;
    double eleva4;
    double eleva6;
    double eleva8;
    double eleva10;


    System.out.print("Insira um numero: ");
    num = s.nextInt();
        
    eleva2 = (Math.pow(num, 2));
    System.out.println("Resultado 2: " + eleva2);


    eleva4 = (Math.pow(num, 4));
    System.out.println("Resultado 3: " + eleva4);


    eleva6 = (Math.pow(num, 6));
    System.out.println("Resultado 4: " + eleva6);

    eleva8 = (Math.pow(num, 8));
    System.out.println("Resultad 8: " + eleva8);

    eleva10 = (Math.pow(num, 10));
    System.out.println("Resultado 10: " + eleva10);



    }   
}
