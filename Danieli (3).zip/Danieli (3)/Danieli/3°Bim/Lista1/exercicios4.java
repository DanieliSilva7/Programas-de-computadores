import java.util.Scanner;

public class exercicios4 {
    
/*/Faça um programa que peça um número ao usuário. 
Exiba se esse número é Par ou Ímpar (use o operador de resto da divisão - mod). */

public static void main(String[] args){
int num1,num2;
Scanner s = new Scanner(System.in);
String resultado="Numeros são iguais:";
/*/ pedir para o usuário /*/

System.out.println("Informe o primeiro numero:");
num1 = s.nextInt();
System.out.println("Informe o segundo número:");
num2 = s.nextInt();

if (num1 > num2) {/*Expressão com resultado lógica */
    resultado = "Num1 é maior que num2!";
/*quando resultado for verdadeiro */

}else{
/*quando resultado for verdadeiro */
resultado = "Numeros são iguais!";
}

System.out.println("Resultado: " + resultado);

}

}