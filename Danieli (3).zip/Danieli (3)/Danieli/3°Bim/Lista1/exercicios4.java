import java.util.Scanner;

public class exercicios4 {
    
/*/Faça um programa que peça um número ao usuário. 
Exiba se esse número é Par ou Ímpar (use o operador de resto da divisão - mod). */

public static void main(String[] args){
    
    int numero;

Scanner s = new Scanner(System.in);
numero = s.nextInt();

System.out.println("Digite um número:");
    

    if (numero % 2 == 0 ) {
    System.out.println("O número" + numero +  "É Par.");

    }else{
    System.out.println("O número" + numero + "é Impar");

        }      

    }

}