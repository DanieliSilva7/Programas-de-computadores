
import java.util.Scanner;

class exerciciosUm{


public static void main(String[] args) {
/*/ Exercicio 01:
/*Faça um programa que peça ao usuário qual foi sua nota final no ano letivo. Se a nota for menor que 6 e maior que 4,
 exiba “precisa fazer prova substitutiva”. Se for maior que 6 exiba “aprovado”. Senão, exiba “reprovado”. 
 */


double nota_final;
Scanner s = new Scanner(System.in);

System.out.print("Informa sua nota fina:");
nota_final = s.nextDouble();

//menor que 6 e maior que 4
if(nota_final< 6 && nota_final > 4)
 { //verdade (true)
System.out.println("Precisa fazer prova substitutiva");

}else if (nota_final >= 6)
{//verdade (true)
System.out.println("Aprovado");

}else
{//falso (false)
System.out.println("Reprovado");


}

}
}