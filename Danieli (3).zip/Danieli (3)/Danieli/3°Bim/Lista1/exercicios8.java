
import java.util.Scanner;

public class exercicios8 {
    /*Faça um programa que peça ao usuário o valor do relógio de água de uma 
    residência no dia 1º do mês e no dia 30º do mesmo mês. Depois mostre quantos litros foram consumidos e a média por dia. considere 30 dias. */
     
    public static void main(String[] arg){
    double leitura_relogio_inicial, leitura_relogio_final;
    double media, consumo;
    Scanner s = new Scanner (System.in);

    System.out.print("Informe o valor do relogio de agua no 1 dia:");
        leitura_relogio_inicial = s.nextDouble();
        System.out.println("Informe o valor do relogio de agua no 30 dia:");
        leitura_relogio_final = s.nextDouble();


        consumo = leitura_relogio_final - leitura_relogio_inicial;
        media = consumo / 30;

        System.out.println("Litros Consumidos:" + consumo + "\nMedia diaria" + media);



    }
}
