import java.util.Scanner;

public class exercicios9 {
 /*Faça um programa que peça ao usuário um número inteiro qualquer. 
 Se ele for maior que 10 e menor que 100, calcule a potência dele elevado a 2.
  Se ele for maior que 100 ou menor que 10, exiba a raiz quadrada do valor. 
  Exiba os valores com 5 casas decimais. */   

  public static void main(String[] args) {
      
  Scanner s = new Scanner(System.in);

      int num;
      double eleva2;
      double raiz;

      System.out.print("Insira um número: ");
      num = s.nextInt();

      eleva2 = Math.pow(num, 2 );

      raiz = Math.sqrt(num);
    

      if(num >=  10 && num  <= 100 ){
        System.out.printf("Resultado 1: %.5f%n  " , eleva2);
      }

      else if(num >= 100 || num <= 10) {
        System.out.printf("Resultado 2: %.5f%n  " , raiz);
      }

      else{
        System.out.println("Por favor informe dados validos: ");
      }



  }
  
}
