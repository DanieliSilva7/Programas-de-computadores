public class atividade7 {
    /*Elabore um algoritmo que efetue a soma de todos os números ímpares
     que são múltiplos de 3 de 1 a 100 (para). 
 */


}
