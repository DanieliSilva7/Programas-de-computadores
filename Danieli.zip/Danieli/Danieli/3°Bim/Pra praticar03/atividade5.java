public class atividade5 {
    
/* Imagine uma brincadeira entre dois colegas onde um fornece um número
 e o outro deve adivinhar qual é. Como dica, indique se o chute dado foi alto ou baixo em
  relação ao número escolhido. Pode sortear um número aleatório também. (repita)
 */

}
