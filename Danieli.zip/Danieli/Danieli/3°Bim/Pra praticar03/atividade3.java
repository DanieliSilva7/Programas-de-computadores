public class atividade3 {
     /*Construa um algoritmo que peça ao usuário dois números e exiba todos os número entre eles. Se o primeiro for menor que o segundo, exiba em ordem crescente
     Senão, exiba em ordem decrescente */ 
}
