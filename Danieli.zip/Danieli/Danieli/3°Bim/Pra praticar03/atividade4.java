public class atividade4 {
    
/*Construa um algoritmo que calcule a soma de números pares que o usuário informar enquanto ele não digitar zero. O usuário pode informar qualquer número entre 0 e 100, mas só deve ser somado se ele for par.
 Encerrar o laço quando o usuário digitar 0. */
public static void  main (String[] arg){












    }

}
