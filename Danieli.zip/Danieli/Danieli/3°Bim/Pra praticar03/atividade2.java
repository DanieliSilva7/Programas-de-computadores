public class atividade2 {
    
    /*Agora repita o exercício anterior e somente exiba a lista de números do exercício anterior se o segundo 
    valor for maior que o primeiro. */
}
