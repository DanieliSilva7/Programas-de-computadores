public class atividade6 {
   /*Elabore um algoritmo que simule uma contagem regressiva de 10 minutos, ou seja,
    mostre 10:00, 9:59, 9:58 até 0:00. (para) */
    

}
