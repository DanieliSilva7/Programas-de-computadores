public class atividade1 {
   
/*1Construa um programa que exiba os valores entre dois números 
informados pelo usuário.*/























}

