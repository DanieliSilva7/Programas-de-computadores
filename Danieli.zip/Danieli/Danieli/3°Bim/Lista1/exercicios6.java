import java.util.Scanner;

public class exercicios6 {
   /*  Faça um programa que peça ao usuário um número inteiro qualquer
    e exiba esse número elevado a 2, 4, 6, 8 e 10 (use a biblioteca Math). */

public static void main(String[] arg) {

    int num;
    Scanner s = new Scanner(System.in);

    System.out.print("Insira um numero: ");
    num = s.nextInt();

    System.out.println("Resultado 2: :" + num + "elevado a 2: ");
    System.out.println("Resultado 4: :" + num + "elevado a 4: ");
    System.out.println("Resultado 6: :" + num + "elevado a 6: ");
    System.out.println("Resultado 8: :" + num + "elevado a 8: ");
    System.out.println("Resultado 10: :" + num + "elevado a 10: ");

    }   
}
