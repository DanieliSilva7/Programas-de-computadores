
import java.util.Scanner;

public class exercicios7 {
    /*Faça um programa que peça ao usuário dois números (num1 e num2) e 
    depois exiba o resultado das operações relacionais maior que, menor que, igual e diferente */

    public static void main(String[] args) {

int num1, num2;
Scanner s = new  Scanner (System.in);

System.out.print ("Informe o primeiro numero" );
num1 = s.nextInt();
System.out.println("Informe o segundo numero");
num2 = s.nextInt();

System.err.println("num1 > num2");

    }

}
