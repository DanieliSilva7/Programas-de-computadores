public class exercicio4 {
    /*Tendo como dados de entrada a altura, o peso e o sexo de uma pessoa, construa um algoritmo que calcule seu peso ideal,
     usando as fórmulas abaixo e exiba se a pessoa está abaixo, no peso ou acima do peso ideal.
	homens: (72.7 * H) - 58
	mulheres: (62.1 * H) - 44.7
 */
}
