public class exercicio10 {
    
}
