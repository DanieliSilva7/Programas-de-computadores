public class exercicio12 {
    
}
