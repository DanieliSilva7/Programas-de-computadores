import java.util.Scanner;
class exemplo_operadores{

public static void main(String[] args) {

int A;
int B;

int soma;
int subtracao;
int multiplicacao;
double divisao;
double resto_divisao;



Scanner s = new Scanner(System.in); // Variável para ler informações do terminal 

System.out.println ("informe os valores de:");
System.out.print ("A: ");
A= s.nextInt();

System.out.print("B: ");
B = s.nextInt();

    soma = A + B;  
    subtracao = A - B; 
    multiplicacao = A * B;
    divisao = A / B;
    resto_divisao = A % B; // 10 % 3 resultado vai ser 1.//

    //exibir na tela//

    System.out.println("Resultados das operacoes entre A e B:");
    System.out.println("soma: " + soma);
    System.out.println("subtracao: " + subtracao);
    System.out.println("multiplicacao: " + multiplicacao);
    System.out.println("divisao: " + divisao);
    System.out.println("resto_divisao: " + resto_divisao);

    System.out.println("Resultado das operações Relacionais entre A e B:");
    System.out.println("A: " + A + "\nB: " + B);
    System.out.println("A<B: " + (A<B) );

    //Criar as variáveis para cada tipo primitivo, peça ao usuário os valores, armaene nas variáveis e depois
    // mostre na tela os valores informados peo usuário:
    int ex_inteiro;
    char ex_char;

    System.out.println("Informe um valor inteiro:");
    ex_inteiro = s.nextInt();
    System.out.println("Valor informado: " + ex_inteiro);

    System.out.println("Informe uma Letra: ");
    ex_char = s.next().charAt(index:0);
    System.out.println("Letra informada:" + ex_char);


}   

}